package com.theveganrobot.cvcamera;

import java.util.LinkedList;

import com.opencv.camera.CameraConfig;
import com.opencv.camera.NativePreviewer;
import com.opencv.camera.NativeProcessor;
import com.opencv.camera.NativeProcessor.PoolCallback;
import com.opencv.jni.image_pool;
import com.opencv.opengl.GL2CameraViewer;
import com.theveganrobot.cvcamera.CVCamera.FastProcessor;
import com.theveganrobot.cvcamera.jni.Processor;
import com.theveganrobot.cvcamera.jni.cvcamera;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageButton;
import android.widget.LinearLayout;

public class MapleUI extends Activity {

	private NativePreviewer mPreview;
	private GL2CameraViewer glview;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		requestWindowFeature(Window.FEATURE_NO_TITLE);
		//getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
		//		WindowManager.LayoutParams.FLAG_FULLSCREEN);

		setContentView(R.layout.mainscrn);
		
		LinearLayout videoFrame = (LinearLayout) findViewById(R.id.vidFrame);
		
		// Create our Preview view and set it as the content of our activity.
		mPreview = new NativePreviewer(getApplication(), 640, 480);
		
		LayoutParams params = new LayoutParams(LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT);
		//LayoutParams params = new LayoutParams(400, 240);
		params.height = getWindowManager().getDefaultDisplay().getHeight() / 2;
		params.width = (int) (params.height * 4.0 / 2.88);

		videoFrame.addView(mPreview, params);
		
		
		
		glview = new GL2CameraViewer(getApplication(), false, 0, 0);
		glview.setZOrderMediaOverlay(true);
		glview.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT));
		
		videoFrame.addView(glview);
		mPreview.setZOrderMediaOverlay(false);
		
		
		ImageButton back_button = (ImageButton) findViewById(R.id.menuButton1);
		back_button.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				
				Intent intent = new Intent(MapleUI.this, CVCamera.class);
				startActivity(intent);

			}
		});
		
		ImageButton capture_button = (ImageButton) findViewById(R.id.menuButton2);
		capture_button.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				
				LinkedList<PoolCallback> defaultcallbackstack = new LinkedList<PoolCallback>();
				defaultcallbackstack.addFirst(glview.getDrawCallback());
				defaultcallbackstack.addFirst(new FastProcessor());
				mPreview.addCallbackStack(defaultcallbackstack);

			}
		});
		
		
		ImageButton settings_button = (ImageButton) findViewById(R.id.menuButtonSettings);
		settings_button.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				
				Intent intent = new Intent(MapleUI.this, CameraConfig.class);
				startActivity(intent);

			}
		});
		
		

	}
	
	@Override
	protected void onPause() {
		super.onPause();

		mPreview.onPause();

		glview.onPause();

	}

	@Override
	protected void onResume() {
		super.onResume();
		glview.onResume();
		mPreview.setParamsFromPrefs(getApplicationContext());
		// add an initiall callback stack to the preview on resume...
		// this one will just draw the frames to opengl
		LinkedList<NativeProcessor.PoolCallback> cbstack = new LinkedList<PoolCallback>();
		cbstack.add(glview.getDrawCallback());
		mPreview.addCallbackStack(cbstack);
		mPreview.onResume();

	}
	
	// final processor so taht these processor callbacks can access it
	final Processor processor = new Processor();

	class FastProcessor implements NativeProcessor.PoolCallback {

		@Override
		public void process(int idx, image_pool pool, long timestamp,
				NativeProcessor nativeProcessor) {
			processor.detectAndDrawFeatures(idx, pool, cvcamera.DETECT_FAST);
			
			//processor.drawText(idx, pool, " detecting leaves  " + idx + " ");
			

		}

	}

}
