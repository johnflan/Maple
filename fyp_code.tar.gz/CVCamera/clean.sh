make OPENCV_ROOT=../../opencv V=0 clean
