This project is also available on https://github.com/johnflan/Maple

For the Android project, the Crystax Android NDK R4 (http://www.crystax.net/android/ndk-r4.php) and OpenCV (http://sourceforge.net/projects/opencvlibrary/) will need to be built on the local machine.

The JavaCV project is self-contained.
