make V=0
