see http://code.google.com/p/android-opencv/wiki/CVCamera

