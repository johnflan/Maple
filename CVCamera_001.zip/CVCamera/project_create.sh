android update project --name CVCamera \
--path .
